﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;

namespace HandGestureV2
{
    public partial class FormFingerDetection : Form
    {
        private Label fingerCountLabel;
        private List<int> fingerGestureHistory = new List<int>();

        // --- PERUBAHAN UTAMA: Dictionary untuk menyimpan semua gestur dan aksinya ---
        // Anda bisa dengan mudah menambahkan gestur baru di sini.
        private Dictionary<List<int>, Action> gestureActions;

        public FormFingerDetection()
        {
            InitializeComponent();
            InitializeCustomComponents();
            // Panggil metode untuk mendaftarkan semua gestur yang kita kenali.
            InitializeGestures();
        }

        /// <summary>
        /// Mendaftarkan semua gestur dan aksi yang akan digunakan oleh aplikasi.
        /// </summary>
        private void InitializeGestures()
        {
            gestureActions = new Dictionary<List<int>, Action>
            {
                // Key: Urutan gestur (List<int>)
                // Value: Aksi yang akan dijalankan (Action)
                
                //{ new List<int> { 1, 2, 3 }, () => OpenApp("calc.exe", "Kalkulator") },
                //{ new List<int> { 1, 3, 2 }, () => OpenApp("chrome.exe", "Google Chrome") },
                //{ new List<int> { 5, 0 },    () => OpenApp("notepad.exe", "Notepad") },
                //{ new List<int> { 2, 5 },    () => OpenApp("mspaint.exe", "MS Paint") },
                //{ new List<int> { 4, 5 },    () => MessageBox.Show($"Waktu sekarang: {DateTime.Now:HH:mm:ss}", "Informasi Waktu") }
            };
        }

        private void InitializeCustomComponents()
        {
            this.fingerCountLabel = new System.Windows.Forms.Label();

            this.fingerCountLabel.AutoSize = true;
            this.fingerCountLabel.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.fingerCountLabel.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.fingerCountLabel.Location = new System.Drawing.Point(12, 9);
            this.fingerCountLabel.Name = "fingerCountLabel";
            this.fingerCountLabel.Text = "Tunjukkan Gestur Anda...";

            this.webView21.Location = new System.Drawing.Point(12, 50);
            this.webView21.Size = new System.Drawing.Size(this.ClientSize.Width - 24, this.ClientSize.Height - 62);
            this.webView21.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);

            this.Controls.Add(this.fingerCountLabel);
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                await webView21.EnsureCoreWebView2Async(null);
                webView21.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

                string htmlFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Hand.html");

                if (File.Exists(htmlFilePath))
                {
                    webView21.CoreWebView2.Navigate(new Uri(htmlFilePath).AbsoluteUri);
                }
                else
                {
                    webView21.CoreWebView2.NavigateToString("<html><body><h1>Error</h1><p>File tidak ditemukan: " + htmlFilePath + "</p></body></html>");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Terjadi error saat memuat halaman: {ex.Message}", "WebView2 Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CoreWebView2_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string fingerCountJson = e.WebMessageAsJson;
            if (int.TryParse(fingerCountJson.Trim('"'), out int currentFingerCount))
            {
                this.Invoke(new Action(() =>
                {
                    fingerCountLabel.Text = $"Jari Terdeteksi: {currentFingerCount}";
                    ProcessGestureForApp(currentFingerCount);
                }));
            }
        }

        /// <summary>
        /// Metode pembantu untuk membuka aplikasi dan menangani error.
        /// </summary>
        private void OpenApp(string processName, string appName)
        {
            try
            {
                Process.Start(processName);
                fingerCountLabel.Text = $"{appName} Dibuka!";
            }
            catch (Exception)
            {
                MessageBox.Show($"Gagal menemukan {appName}. Pastikan aplikasi terinstal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Memproses gestur sekuensial dan mencocokkannya dengan aksi di Dictionary.
        /// </summary>
        private void ProcessGestureForApp(int currentFingerCount)
        {
            // Tambahkan gestur baru jika berbeda dari yang terakhir.
            if (fingerGestureHistory.Count == 0 || fingerGestureHistory.Last() != currentFingerCount)
            {
                fingerGestureHistory.Add(currentFingerCount);
            }

            // Batasi ukuran histori.
            if (fingerGestureHistory.Count > 10)
            {
                fingerGestureHistory.RemoveAt(0);
            }

            // Iterasi melalui setiap gestur yang terdaftar di Dictionary.
            foreach (var gestureEntry in gestureActions)
            {
                var targetGesture = gestureEntry.Key;
                var action = gestureEntry.Value;

                // Cek apakah histori gestur terbaru cocok dengan target.
                if (fingerGestureHistory.Count >= targetGesture.Count &&
                    fingerGestureHistory.Skip(fingerGestureHistory.Count - targetGesture.Count).SequenceEqual(targetGesture))
                {
                    // Jika cocok, jalankan aksi yang sesuai.
                    action.Invoke();

                    // Kosongkan histori untuk memulai deteksi gestur baru.
                    fingerGestureHistory.Clear();

                    // Keluar dari loop setelah menemukan gestur yang cocok.
                    return;
                }
            }
        }
    }
}
